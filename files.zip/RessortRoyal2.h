#pragma once

// ========================================
// INCLUDES ET DÉPENDANCES
// ========================================
#include "ArduinoJson.h"
#include <memory>
#include "Node/Node.h"
#include "PLC_Persistence/PLC_Persistence.h"
#include "RenderTools/RenderTools.h"
#include "PLC_CommonTypes/PLC_CommonTypes.h"
#include "BusinessLogic/BusinessLogic.h"
#include "PLC_Tools/PLC_Tools.h"
#include "BusinessLogic/BusinessLogic.inl"
#include "SureServo/SureServo.h"

// ========================================
// UTILITAIRES DE COMPILATION
// ========================================
#define STRINGIFY(x) #x
#define TOSTRING(x) STRINGIFY(x)

// ========================================
// CONFIGURATION ET DÉLAIS
// ========================================
#define DELAY_INIT                  100     // 100ms
#define CONSTR_RESSORT_ROYAL2      "Constructeur class RessortRoyal2"
#define CONFIG_FILE_NAME           "/RessortRoyal2.json"

// ========================================
// IDENTIFIANTS DE NŒUDS (HASH CODES)
// ========================================

// Nœuds de contrôle principal
#define BUZZER                     1711197005
#define ESTOPA                     721063196
#define ESTOPB                     998762341
#define START_CYCLE                2986050054

// Nœuds de sortie Kincony
#define SERVOON                    1927398708
#define TRIGGER_PR                 4235117271
#define IMMEDIATE_STOP             973196112
#define ALARMS_RESET               4138453966
#define FREE_RUN                   2015677485
#define GO_AND_BACK                3029257395

// Nœuds JOG
#define JOG                        627952477
#define FWD                        936928435
#define RWD                        2405696470
#define FULL_TORQUE                313736047

// Nœuds de status servo
#define SERVOREADY                 1578545169
#define SERVOACTIVATED             1878960780
#define ZEROSPEED                  3381240120
#define TARGETSPEEDRATED           204382134
#define ATTARGET                   2857997314
#define SERVOALARM                 1036420395
#define ABSOLUTE_POS_LOST          1845100150
#define BATTERYALARM               1229514833
#define MULTIPLETURNSOVERFLOW      4013941733
#define PUUOVERFLOW                3738696056
#define ABSOLUTECOORDONATENOTSET   2023813836
#define HOMEDONE                   3171404866
#define MODBUSERROR                460376054
#define DRIVEINITIALISED           714661227

// Nœuds d'entrée utilisateur (paramètres)
#define USER_TARGET                645363011
#define RETURN_POS                 396324830
#define VJOG_SPEED                 2984797290
#define VCYCLE_SPEED               1951357668
#define NUMBER_OF_CYCLES_TO_DO     3526906192
#define NUMBER_OF_CYCLES_MADE      3822078925
#define NB_CYCLES_CLEAR            1168588921

// Nœuds Modbus read holding register
#define STATUS_DRIVE               4137233651
#define ABSOLUTE_COORDONATE_SYSTEM_STATUS 4098304980
#define ALARMS                     4126332617
#define TRIGGER_READ               4059768218
#define JOG_SPEED_READ             4031699079

// Nœuds Modbus write holding register
#define AUX_FUNCTION               2308213873
#define TRIGGER                    748480285
#define JOG_SPEED                  3187488644
#define MAX_TORQUE                 3740987040

// Nœuds Modbus read double holding register
#define POSITION                   4045003206
#define TORQUE                     1761329095
#define TARGET_GO_READ             2843041799
#define TARGET_BACK_READ           2152625540
#define PR1_SPEED_READ             1103145540

// Nœuds Modbus write double holding register
#define TARGET_GO                  2532989225
#define TARGET_BACK                3432736329
#define PR1_SPEED                  1282109782
#define PR2_SPEED                  2019104905

// ========================================
// CLÉS JSON POUR LA CONFIGURATION
// ========================================
#define MACHINE_NAME_KEY           "machine name"
#define DEFAULT_MACHINE_NAME       "RessortRoyal2"
#define USER_TARGET_KEY            "user target"
#define RETURN_POS_KEY             "return position"
#define JOG_SPEED_KEY              "jog speed"
#define CYCLE_SPEED_KEY            "cycle speed"
#define NUMBER_OF_CYCLES_KEY       "number of cycles to do"
#define FULL_TORQUE_KEY            "full torque"
#define INITIAL_TORQUE_KEY         "initial torque [%]"

// ========================================
// STRUCTURE PERSISTANT_PARAMETERS
// ========================================
struct PERSISTANT_PARAMETERS {
    // Paramètres machine de base
    String machineName;
    MACHINE machine;
    
    // Paramètres de mouvement
    uint32_t userTarget;        // Position cible définie par l'utilisateur
    uint32_t returnPos;         // Position de retour
    uint16_t jogSpeed;          // Vitesse en mode JOG
    uint16_t cycleSpeed;        // Vitesse en mode cycle
    
    // Paramètres de cycle
    uint32_t numberOfCyclesToDo;   // Nombre de cycles à effectuer
    uint32_t numberOfCyclesMade;   // Nombre de cycles effectués
    
    // Paramètres de contrôle
    bool fullTorque;            // Mode couple maximal
    uint16_t initialTorque;     // Couple initial en %
    
    // Constructeur par défaut
    PERSISTANT_PARAMETERS() :
        machineName(DEFAULT_MACHINE_NAME),
        machine(),
        userTarget(0),
        returnPos(0),
        jogSpeed(500),
        cycleSpeed(1000),
        numberOfCyclesToDo(0),
        numberOfCyclesMade(0),
        fullTorque(false),
        initialTorque(50)
    {}
};

/**
 * @brief Classe métier pour RessortRoyal2
 * 
 * Système de test de ressorts avec servo moteur.
 * Fonctionnalités principales :
 * - Mode JOG manuel (avant/arrière)
 * - Mode cycle automatique (aller-retour)
 * - Mode free run
 * - Compteur de cycles
 * - Gestion des alarmes et arrêts d'urgence
 * 
 * Design Patterns utilisés:
 * - State Pattern (hérité de BusinessLogic)
 * - Template Method (initNodePtr)
 * - Observer Pattern (callbacks de transition)
 * - Factory Pattern (création des nœuds)
 */
class RessortRoyal2 : public BusinessLogic {

public:
    // ========================================
    // ÉNUMÉRATION DES ÉTATS
    // ========================================
    
    /**
     * @brief États de la machine RessortRoyal2
     * 
     * Utilise enum class pour un typage fort et éviter les collisions de noms
     */
    enum class State : int {
        // Les états de base hérités de BusinessLogic
        UNDEFINED = static_cast<int>(BaseState::UNDEFINED),
        INITIALIZING = static_cast<int>(BaseState::INITIALIZING),
        STOP = static_cast<int>(BaseState::STOP),
        IDLE = static_cast<int>(BaseState::IDLE),
        EMERGENCY = static_cast<int>(BaseState::EMERGENCY),

        // États spécifiques RessortRoyal2
        HOMING = 100,           // Recherche de l'origine
        JOGGING = 101,          // Mode JOG manuel
        FREE_RUNNING = 102,     // Mode free run
        CYCLING = 103,          // Mode cycle automatique
        GOING = 104,            // Phase aller du cycle
        RETURNING = 105         // Phase retour du cycle
    };

    // ========================================
    // X MACRO définition de la table des états
    // ========================================
    #define RESSORT_ROYAL2_STATE_TABLE \
        X(UNDEFINED,        TRANSIENT,  "État non défini") \
        X(INITIALIZING,     TRANSIENT,  "Initialisation en cours") \
        X(STOP,             STABLE,     "Machine arrêtée") \
        X(IDLE,             STABLE,     "Attente de commande") \
        X(EMERGENCY,        EMERGENCY,  "Arrêt d'urgence") \
        X(HOMING,           UTILITY,    "Recherche origine") \
        X(JOGGING,          UTILITY,    "Mode JOG manuel") \
        X(FREE_RUNNING,     STABLE,     "Mode free run") \
        X(CYCLING,          STABLE,     "Mode cycle automatique") \
        X(GOING,            TRANSIENT,  "Phase aller") \
        X(RETURNING,        TRANSIENT,  "Phase retour")

    /**
     * @brief Obtient le nom d'un état depuis la X-Macro
     */
    static const char* getStateNameFromTable(State state);
    static StateType getStateTypeFromTable(State state);
    
    /**
     * @brief Obtient la catégorie d'un état (TRANSIENT, STABLE, EMERGENCY, UTILITY)
     */
    static const char* getStateCategoryFromTable(State state);
    
    /**
     * @brief Obtient la description d'un état
     */
    static const char* getStateDescriptionFromTable(State state);

    // ========================================
    // CODES DE CONTEXTE POUR LES TRANSITIONS
    // ========================================
    enum class ContextCode : uint8_t {
        // Contextes normaux
        NORMAL = 0,
        AUTO_DETECT = 1,
        BEFORE_UTILITY = 2,
        MOVEMENT_SUCCESS = 3,
        POSITION_REACHED = 4,
        CYCLE_COMPLETE = 5,
        
        // Contextes d'urgence
        EMERGENCY_STOP = 10,
        SERVO_ALARM = 11,
        SERVO_NOT_READY = 12,
        
        // Contextes utilisateur
        USER_REQUEST = 20,
        BUTTON_PRESSED = 21,
        
        // Contextes d'erreur
        TIMEOUT = 30,
        INIT_FAILED = 31
    };

    // ========================================
    // CONSTRUCTEUR / DESTRUCTEUR
    // ========================================
    RessortRoyal2();
    virtual ~RessortRoyal2();

    // ========================================
    // MÉTHODES PUBLIQUES
    // ========================================
    
    /**
     * @brief Initialise les pointeurs vers les nœuds
     * @param context Contexte de l'appel (pour debug)
     * @return true si succès
     */
    bool initializePointers(const char* context) override;

    /**
     * @brief Configure les nœuds après leur création
     * @return true si succès
     */
    bool setupNodes() override;

    /**
     * @brief Démarre la machine d'états
     * @return true si succès
     */
    bool startStateMachine() override;
    
    /**
     * @brief Exécute la logique métier principale (boucle)
     * @return true si succès
     */
    bool doBusinessLogic();

    // ========================================
    // MÉTHODES VIRTUELLES DE BusinessLogic
    // ========================================
    
    /**
     * @brief Convertit un état en chaîne de caractères
     */
    const char* stateToString(int state) const override;
    
    /**
     * @brief Obtient le type d'un état
     */
    StateType getStateType(int state) const override;

    /**
     * @brief Handler appelé après le chargement de l'état initial
     */
    void initialStateLoadedHandler() override;

    /**
     * @brief Handler appelé quand un fichier est sauvegardé
     */
    void onFileSaved(const char* path) override;

    /**
     * @brief Valide un fichier de configuration avant sauvegarde
     */
    bool validateConfigFile(const char* path, const JsonDocument& doc, String& errorMsg) override;

    /**
     * @brief Vérifie si un fichier peut être supprimé
     */
    bool canDeleteFile(const char* path) override;

protected:
    // ========================================
    // HOOKS DE TRANSITION (OVERRIDES)
    // ========================================
    
    /**
     * @brief Hook appelé lors de l'entrée dans un nouvel état
     */
    void onStateEnter(int newState, int oldState) override;
    
    /**
     * @brief Hook appelé lors de la sortie d'un état
     */
    void onStateExit(int oldState, int newState) override;
    
    /**
     * @brief Hook appelé après qu'une transition soit complète
     */
    void onTransitionComplete(int newState, int oldState) override;

private:
    // ========================================
    // POINTEURS VERS LES NŒUDS
    // ========================================
    
    // === NŒUDS DE CONTRÔLE PRINCIPAL ===
    BooleanOutputNode* buzzer = nullptr;
    BooleanInputNode* eStopA = nullptr;
    BooleanInputNode* eStopB = nullptr;
    BooleanInputNode* startCycle = nullptr;

    // === NŒUDS DE SORTIE KINCONY ===
    BooleanOutputNode* servoOn = nullptr;
    BooleanOutputNode* triggerPR = nullptr;
    BooleanOutputNode* immediateStop = nullptr;
    BooleanOutputNode* alarmsReset = nullptr;
    BooleanOutputNode* freeRun = nullptr;
    BooleanOutputNode* goAndBack = nullptr;

    // === NŒUDS JOG ===
    BooleanOutputNode* jog = nullptr;
    BooleanOutputNode* fwd = nullptr;
    BooleanOutputNode* rwd = nullptr;
    BooleanOutputNode* fullTorque = nullptr;

    // === NŒUDS DE STATUS SERVO ===
    BooleanInputNode* servoReady = nullptr;
    BooleanInputNode* servoActivated = nullptr;
    BooleanInputNode* zeroSpeed = nullptr;
    BooleanInputNode* targetSpeedRated = nullptr;
    BooleanInputNode* atTarget = nullptr;
    BooleanInputNode* servoAlarm = nullptr;
    BooleanInputNode* absolutePositionLost = nullptr;
    BooleanInputNode* batteryAlarm = nullptr;
    BooleanInputNode* multipleTurnsOverflow = nullptr;
    BooleanInputNode* puuOverflow = nullptr;
    BooleanInputNode* absoluteCoordonateNotSet = nullptr;
    BooleanInputNode* homeDone = nullptr;
    BooleanInputNode* modbusError = nullptr;
    BooleanInputNode* driveInitialised = nullptr;

    // === NŒUDS D'ENTRÉE UTILISATEUR ===
    Uint32OutputNode* userTarget = nullptr;
    Uint32OutputNode* returnPos = nullptr;
    Uint32OutputNode* vJogSpeed = nullptr;
    Uint32OutputNode* vCycleSpeed = nullptr;
    Uint32OutputNode* numberOfCyclesToDo = nullptr;
    Uint32InputNode* numberOfCyclesMade = nullptr;
    BooleanOutputNode* nbCyclesClear = nullptr;

    // === NŒUDS MODBUS READ HOLDING REGISTER ===
    Uint16InputNode* statusDrive = nullptr;
    Uint16InputNode* absoluteCoordonateSystemStatus = nullptr;
    Uint16InputNode* alarms = nullptr;
    Uint16InputNode* triggerRead = nullptr;
    Uint16InputNode* jogSpeedRead = nullptr;

    // === NŒUDS MODBUS WRITE HOLDING REGISTER ===
    Uint16OutputNode* auxFunction = nullptr;
    Uint16OutputNode* trigger = nullptr;
    Uint16OutputNode* jogSpeed = nullptr;
    Uint16OutputNode* maxTorque = nullptr;

    // === NŒUDS MODBUS READ DOUBLE HOLDING REGISTER ===
    Uint32InputNode* position = nullptr;
    Uint32InputNode* torque = nullptr;
    Uint32InputNode* targetGoRead = nullptr;
    Uint32InputNode* targetBackRead = nullptr;
    Uint32InputNode* pr1SpeedRead = nullptr;

    // === NŒUDS MODBUS WRITE DOUBLE HOLDING REGISTER ===
    Uint32OutputNode* targetGo = nullptr;
    Uint32OutputNode* targetBack = nullptr;
    Uint32OutputNode* pr1Speed = nullptr;
    Uint32OutputNode* pr2Speed = nullptr;

    // === SERVO DRIVE ===
    std::unique_ptr<SureServo> sureServo = nullptr;
    SureServo* getSureServo() const { return sureServo.get(); }
    bool driveInitStarted = false;
    bool resetDrive(const char* context);
    bool resetInProgress = false;

    // ========================================
    // HANDLERS D'ÉTATS - À IMPLÉMENTER
    // ========================================
    bool handleUndefinedState(uint32_t now);
    bool handleInitializingState(uint32_t now);
    bool handleStopState(uint32_t now);
    bool handleIdleState(uint32_t now);
    bool handleEmergencyState(uint32_t now);
    bool handleHomingState(uint32_t now);
    bool handleJoggingState(uint32_t now);
    bool handleFreeRunningState(uint32_t now);
    bool handleCyclingState(uint32_t now);
    bool handleGoingState(uint32_t now);
    bool handleReturningState(uint32_t now);

    // ========================================
    // MÉTHODES UTILITAIRES
    // ========================================
    
    /**
     * @brief Gère les conditions d'urgence
     */
    void checkEmergencyConditions(uint32_t now);

    /**
     * @brief Gère les interruptions
     */
    void handleInterrupts();

    /**
     * @brief Met à jour les sorties
     */
    void updateOutputs();

    /**
     * @brief Traitement de l'interface
     */
    void interfaceTreatment();

    /**
     * @brief Affiche les alarmes et le status
     */
    void displayAlarmsAndStatus();

    /**
     * @brief Obtient l'état courant
     */
    State getCurrentState() const {
        return static_cast<State>(BusinessLogic::getCurrentState());
    }
    
    /**
     * @brief Transition vers un nouvel état avec contexte
     */
    void transitionToState(State newState, ContextCode contextCode = ContextCode::NORMAL);

    /**
     * @brief Configure la vitesse JOG
     */
    bool setJogSpeed(uint32_t speed);

    /**
     * @brief Configure la vitesse de cycle
     */
    void cycleSpeedChange();

    // ========================================
    // GESTION DES FICHIERS DE CONFIGURATION
    // ========================================
    
    /**
     * @brief Gère le rechargement automatique du fichier RessortRoyal2.json
     */
    void handleRessortRoyal2ConfigFileChanged();
    
    /**
     * @brief Applique les paramètres persistants aux nodes
     */
    void applyParametersToNodes();
    
    /**
     * @brief Lit le fichier de configuration dédié
     */
    bool readDedicacedConfigFile();
    
    /**
     * @brief Extrait les paramètres machine du document JSON
     */
    bool extractMachineParameters(const JsonDocument& doc);
    
    /**
     * @brief Détermine l'état de retour après emergency
     */
    State getEmergencyReturnState() const;

    // ========================================
    // VARIABLES MEMBRES
    // ========================================
    
    // Objets persistants
    PERSISTANT_PARAMETERS parameters;
    PLC_Persistence& persistence = PLC_Persistence::getInstance();

    // Variables d'état
    uint32_t currentJogSpeed = 0;
    uint32_t cycleCounter = 0;
    bool inCycle = false;
    bool goingPhase = true;  // true = aller, false = retour
    
    // Variables pour emergency
    uint8_t emergencyPhase = 0;
    State emergencyTargetState = State::STOP;
    
    // Variables pour les mouvements
    bool goingMovementStarted = false;
    bool returningMovementStarted = false;
};
