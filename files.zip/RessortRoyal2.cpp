#include "RessortRoyal2.h"

// ========================================
// CONSTRUCTEUR
// ========================================

RessortRoyal2::RessortRoyal2() : BusinessLogic() {
    
    #ifdef UNIT_TEST_MODE
        currentState = (int)State::UNDEFINED;
        previousState = (int)State::UNDEFINED;
        Serial.println("Mode TEST");
        return;
    #endif

    Serial.println("RessortRoyal2() étape 1: constructeur BusinessLogic");
    currentState = static_cast<int>(State::UNDEFINED);
    previousState = static_cast<int>(State::UNDEFINED);
    stateStartTime = millis();
    
    Serial.println("RessortRoyal2() étape 2: callback MemoryMonitor");
    static bool callbackRegistered = false;
    if (!callbackRegistered) {
        MemoryMonitor::setCleanupCallback([]() {
            PLC_Tools::cleanupThrottleMaps();
        });
        callbackRegistered = true;
    }
    
    Serial.println("RessortRoyal2() étape 3: get BorneUniverselle");
    BorneUniverselle* instance = BorneUniverselle::getInstance();
    
    Serial.println("RessortRoyal2() étape 4: register callback");
    instance->setInitialStateLoadedCallback([this]() {
        this->initialStateLoadedHandler();
    });

    // Lecture du fichier de configuration
    if (!readDedicacedConfigFile()){
        Serial.println("Erreur lors de la lecture du fichier de configuration dédié au projet");
    } else {
        Serial.println("Fichier de configuration dédié au projet lu avec succès");
    }

    Serial.println("⚠️ Lecture config reportée à initialStateLoadedHandler");
    Serial.println("Fin du constructeur RessortRoyal2");
}

// ========================================
// DESTRUCTEUR
// ========================================

RessortRoyal2::~RessortRoyal2() {
    Serial.println("RessortRoyal2::~RessortRoyal2()");
}

// ========================================
// MÉTHODES X-MACRO POUR LA TABLE DES ÉTATS
// ========================================

const char* RessortRoyal2::getStateNameFromTable(State state) {
    #define X(name, category, description) \
        if (state == State::name) return #name;
    
    RESSORT_ROYAL2_STATE_TABLE
    
    #undef X
    
    return "UNKNOWN_STATE";
}

const char* RessortRoyal2::getStateCategoryFromTable(State state) {
    #define X(name, category, description) \
        if (state == State::name) return #category;
    
    RESSORT_ROYAL2_STATE_TABLE
    
    #undef X
    
    return "UNKNOWN";
}

const char* RessortRoyal2::getStateDescriptionFromTable(State state) {
    #define X(name, category, description) \
        if (state == State::name) return description;
    
    RESSORT_ROYAL2_STATE_TABLE
    
    #undef X
    
    return "État inconnu";
}

BusinessLogic::StateType RessortRoyal2::getStateTypeFromTable(State state) {
    #define X(name, category, description) \
        if (state == State::name) { \
            if (strcmp(#category, "STABLE") == 0) return StateType::STABLE; \
            if (strcmp(#category, "TRANSIENT") == 0) return StateType::TRANSIENT; \
            if (strcmp(#category, "UTILITY") == 0) return StateType::UTILITY; \
            if (strcmp(#category, "EMERGENCY") == 0) return StateType::EMERGENCY; \
        }
    
    RESSORT_ROYAL2_STATE_TABLE
    
    #undef X
    
    return StateType::TRANSIENT;
}

// ========================================
// OVERRIDE BUSINESSLOGIC
// ========================================

const char* RessortRoyal2::stateToString(int state) const {
    return getStateNameFromTable(static_cast<State>(state));
}

BusinessLogic::StateType RessortRoyal2::getStateType(int state) const {
    return getStateTypeFromTable(static_cast<State>(state));
}

// ========================================
// LECTURE DU FICHIER DE CONFIGURATION
// ========================================

bool RessortRoyal2::readDedicacedConfigFile() { 
    Serial.println("========================================");
    Serial.println("RessortRoyal2::readDedicacedConfigFile - Début");
    Serial.println("========================================");
    
    BorneUniverselle* instance = BorneUniverselle::getInstance();
    if (!instance) {
        Serial.println("ERREUR: Instance BorneUniverselle non disponible");
        return false;
    }
    
    // ========================================
    // ÉTAPE 1 : LIRE LE FICHIER RessortRoyal2.json
    // ========================================
    SafeJsonDocument doc(8192); 

    if (!persistence.readJsonFromFile(CONFIG_FILE_NAME, doc)) {
        char errorMsg[256];
        snprintf(errorMsg, sizeof(errorMsg), "Erreur lecture fichier %s: %s", 
                CONFIG_FILE_NAME, persistence.getLastError());
        Serial.println(errorMsg);
        instance->setPlcBroken(errorMsg);
        return false;
    }
    
    Serial.println("✅ Fichier RessortRoyal2.json lu avec succès");

    // ========================================
    // ÉTAPE 2 : EXTRAIRE LES PARAMÈTRES MACHINE
    // ========================================
    if (!extractMachineParameters(doc)) {
        Serial.println("❌ Échec extraction paramètres machine");
        return false;
    }
    
    Serial.println("✅ Paramètres machine extraits");
    
    Serial.println("========================================");
    Serial.println("RessortRoyal2::readDedicacedConfigFile - Terminé");
    Serial.println("========================================");
    return true;
}

// ========================================
// EXTRACTION DES PARAMÈTRES MACHINE
// ========================================

bool RessortRoyal2::extractMachineParameters(const JsonDocument& doc) {
    Serial.println("RessortRoyal2::extractMachineParameters - Début");
    
    // Nom de la machine
    if (doc.containsKey(MACHINE_NAME_KEY)) {
        parameters.machineName = doc[MACHINE_NAME_KEY].as<String>();
        Serial.printf("  Machine name: %s\n", parameters.machineName.c_str());
    } else {
        parameters.machineName = DEFAULT_MACHINE_NAME;
        Serial.printf("  Machine name par défaut: %s\n", parameters.machineName.c_str());
    }
    
    // Paramètres de mouvement
    if (doc.containsKey(USER_TARGET_KEY)) {
        parameters.userTarget = doc[USER_TARGET_KEY].as<uint32_t>();
        Serial.printf("  User target: %u\n", parameters.userTarget);
    }
    
    if (doc.containsKey(RETURN_POS_KEY)) {
        parameters.returnPos = doc[RETURN_POS_KEY].as<uint32_t>();
        Serial.printf("  Return position: %u\n", parameters.returnPos);
    }
    
    if (doc.containsKey(JOG_SPEED_KEY)) {
        parameters.jogSpeed = doc[JOG_SPEED_KEY].as<uint16_t>();
        Serial.printf("  Jog speed: %u\n", parameters.jogSpeed);
    }
    
    if (doc.containsKey(CYCLE_SPEED_KEY)) {
        parameters.cycleSpeed = doc[CYCLE_SPEED_KEY].as<uint16_t>();
        Serial.printf("  Cycle speed: %u\n", parameters.cycleSpeed);
    }
    
    if (doc.containsKey(NUMBER_OF_CYCLES_KEY)) {
        parameters.numberOfCyclesToDo = doc[NUMBER_OF_CYCLES_KEY].as<uint32_t>();
        Serial.printf("  Number of cycles: %u\n", parameters.numberOfCyclesToDo);
    }
    
    // Paramètres de contrôle
    if (doc.containsKey(FULL_TORQUE_KEY)) {
        parameters.fullTorque = doc[FULL_TORQUE_KEY].as<bool>();
        Serial.printf("  Full torque: %s\n", parameters.fullTorque ? "true" : "false");
    }
    
    if (doc.containsKey(INITIAL_TORQUE_KEY)) {
        parameters.initialTorque = doc[INITIAL_TORQUE_KEY].as<uint16_t>();
        Serial.printf("  Initial torque: %u%%\n", parameters.initialTorque);
    }
    
    Serial.println("RessortRoyal2::extractMachineParameters - Terminé");
    return true;
}

// ========================================
// INITIALISATION DES POINTEURS DE NŒUDS
// ========================================

bool RessortRoyal2::initializePointers(const char* contexte) {
    Serial.println("========================================");
    Serial.printf("RessortRoyal2::initializePointers - Début (%s)\n", contexte);
    Serial.println("========================================");
    
    // === NŒUDS DE CONTRÔLE PRINCIPAL ===
    initNodePtr(buzzer, BUZZER, contexte);
    initNodePtr(eStopA, ESTOPA, contexte);
    initNodePtr(eStopB, ESTOPB, contexte);
    initNodePtr(startCycle, START_CYCLE, contexte);
    
    // === NŒUDS DE SORTIE KINCONY ===
    initNodePtr(servoOn, SERVOON, contexte);
    initNodePtr(triggerPR, TRIGGER_PR, contexte);
    initNodePtr(immediateStop, IMMEDIATE_STOP, contexte);
    initNodePtr(alarmsReset, ALARMS_RESET, contexte);
    initNodePtr(freeRun, FREE_RUN, contexte);
    initNodePtr(goAndBack, GO_AND_BACK, contexte);
    
    // === NŒUDS JOG ===
    initNodePtr(jog, JOG, contexte);
    initNodePtr(fwd, FWD, contexte);
    initNodePtr(rwd, RWD, contexte);
    initNodePtr(fullTorque, FULL_TORQUE, contexte);
    
    // === NŒUDS DE STATUS SERVO ===
    initNodePtr(servoReady, SERVOREADY, contexte);
    initNodePtr(servoActivated, SERVOACTIVATED, contexte);
    initNodePtr(zeroSpeed, ZEROSPEED, contexte);
    initNodePtr(targetSpeedRated, TARGETSPEEDRATED, contexte);
    initNodePtr(atTarget, ATTARGET, contexte);
    initNodePtr(servoAlarm, SERVOALARM, contexte);
    initNodePtr(absolutePositionLost, ABSOLUTE_POS_LOST, contexte);
    initNodePtr(batteryAlarm, BATTERYALARM, contexte);
    initNodePtr(multipleTurnsOverflow, MULTIPLETURNSOVERFLOW, contexte);
    initNodePtr(puuOverflow, PUUOVERFLOW, contexte);
    initNodePtr(absoluteCoordonateNotSet, ABSOLUTECOORDONATENOTSET, contexte);
    initNodePtr(homeDone, HOMEDONE, contexte);
    initNodePtr(modbusError, MODBUSERROR, contexte);
    initNodePtr(driveInitialised, DRIVEINITIALISED, contexte);
    
    // === NŒUDS D'ENTRÉE UTILISATEUR ===
    initNodePtr(userTarget, USER_TARGET, contexte);
    initNodePtr(returnPos, RETURN_POS, contexte);
    initNodePtr(vJogSpeed, VJOG_SPEED, contexte);
    initNodePtr(vCycleSpeed, VCYCLE_SPEED, contexte);
    initNodePtr(numberOfCyclesToDo, NUMBER_OF_CYCLES_TO_DO, contexte);
    initNodePtr(numberOfCyclesMade, NUMBER_OF_CYCLES_MADE, contexte);
    initNodePtr(nbCyclesClear, NB_CYCLES_CLEAR, contexte);
    
    // === NŒUDS MODBUS READ HOLDING REGISTER ===
    initNodePtr(statusDrive, STATUS_DRIVE, contexte);
    initNodePtr(absoluteCoordonateSystemStatus, ABSOLUTE_COORDONATE_SYSTEM_STATUS, contexte);
    initNodePtr(alarms, ALARMS, contexte);
    initNodePtr(triggerRead, TRIGGER_READ, contexte);
    initNodePtr(jogSpeedRead, JOG_SPEED_READ, contexte);
    
    // === NŒUDS MODBUS WRITE HOLDING REGISTER ===
    initNodePtr(auxFunction, AUX_FUNCTION, contexte);
    initNodePtr(trigger, TRIGGER, contexte);
    initNodePtr(jogSpeed, JOG_SPEED, contexte);
    initNodePtr(maxTorque, MAX_TORQUE, contexte);
    
    // === NŒUDS MODBUS READ DOUBLE HOLDING REGISTER ===
    initNodePtr(position, POSITION, contexte);
    initNodePtr(torque, TORQUE, contexte);
    initNodePtr(targetGoRead, TARGET_GO_READ, contexte);
    initNodePtr(targetBackRead, TARGET_BACK_READ, contexte);
    initNodePtr(pr1SpeedRead, PR1_SPEED_READ, contexte);
    
    // === NŒUDS MODBUS WRITE DOUBLE HOLDING REGISTER ===
    initNodePtr(targetGo, TARGET_GO, contexte);
    initNodePtr(targetBack, TARGET_BACK, contexte);
    initNodePtr(pr1Speed, PR1_SPEED, contexte);
    initNodePtr(pr2Speed, PR2_SPEED, contexte);
    
    Serial.println("=== CRÉATION SURESERVO ===");
    
    // Préparer la structure des nœuds pour SureServo
    ServoNodes servoNodes;
    servoNodes.servoReady = servoReady;
    servoNodes.servoActivated = servoActivated;
    servoNodes.servoAlarm = servoAlarm;
    servoNodes.homeDone = homeDone;
    servoNodes.modbusError = modbusError;
    servoNodes.driveInitialised = driveInitialised;
    servoNodes.absolutePositionLost = absolutePositionLost;
    servoNodes.batteryAlarm = batteryAlarm;
    servoNodes.multipleTurnsOverflow = multipleTurnsOverflow;
    servoNodes.puuOverflow = puuOverflow;
    servoNodes.absoluteCoordonateNotSet = absoluteCoordonateNotSet;
    
    // Créer le SureServo (pas de conversion PUU pour RessortRoyal2, on utilise 1:1)
    const uint32_t PULSES_PER_UNIT = 1;  // Pas de conversion, travail direct en pulses
    const uint32_t MAX_RANGE = 1000000;  // 1 million de pulses max
    
    sureServo = std::make_unique<SureServo>(PULSES_PER_UNIT, servoNodes, MAX_RANGE);
 
    if (!sureServo) {
        BorneUniverselle::getInstance()->setPlcBroken("Échec création SureServo - pointeur null");
        return false;
    }

    // Vérification que le constructeur s'est bien passé
    const char* lastError = sureServo->getLastError();
    if (lastError && strlen(lastError) > 0 && strcmp(lastError, "Pas d'erreur") != 0) {
        String errorMsg = "Erreur SureServo: ";
        errorMsg += lastError;
        BorneUniverselle::getInstance()->setPlcBroken(errorMsg.c_str());
        Serial.println(errorMsg);
        return false;
    }
    
    Serial.println("✅ SureServo créé avec succès");
    sureServo->printConfiguration();

    // Vérifier si des erreurs se sont produites pendant l'initialisation
    if (BorneUniverselle::getInstance()->isPlcBroken()) {
        Serial.println("Erreur détectée pendant l'initialisation des pointeurs");
        return false;
    }

    applyParametersToNodes();
    
    Serial.println("RessortRoyal2::initializePointers - Fin avec succès");
    Serial.println("========================================");
    return true;
}

// ========================================
// SETUP NODES
// ========================================

bool RessortRoyal2::setupNodes() {
    Serial.println("RessortRoyal2::setupNodes()");
    
    // Configuration des callbacks si nécessaire
    // Pour l'instant, RessortRoyal2 n'a pas de callbacks spécifiques
    
    return true;
}

// ========================================
// INITIAL STATE LOADED HANDLER
// ========================================

void RessortRoyal2::initialStateLoadedHandler() {
    uint32_t start = millis();
    Serial.println("🌐 NEW CLIENT CONNECTED AND LOADED!");
    Serial.println("========================================");
    Serial.println("RessortRoyal2::initialStateLoadedHandler - Début");
    Serial.println("========================================");
    
    // ====================================================================
    // SYNCHRONISATION DE L'ÉTAT AVEC LE NOUVEAU CLIENT
    // ====================================================================
    
    // État du servo
    if (servoOn) {
        Serial.printf("ServoOn state synchronized: %s\n", 
                     servoOn->getValue() ? "ON" : "OFF");
    }
    
    // État initial du jog (toujours faux au démarrage)
    if (jog) {
        jog->setValue(false);
        Serial.println("Jog initialized to false");
    }
    
    // ====================================================================
    // MESSAGES D'ÉTAT POUR LE NOUVEAU CLIENT
    // ====================================================================
    
    if (getCurrentState() == State::EMERGENCY) {
        BorneUniverselle::prepareMessage(ERROR, 
            "Attention ! Machine en arrêt d'urgence");
        Serial.println("Client notified: EMERGENCY state");
    }
    
    if (immediateStop && immediateStop->getValue()) {
        BorneUniverselle::prepareMessage(ERROR, 
            "Arrêt immédiat actif - E_STOP ou problème servo drive");
        Serial.println("Client notified: Immediate stop active");
    }
    
    // ====================================================================
    // APPLICATION DES PARAMÈTRES PERSISTANTS
    // ====================================================================
    
    Serial.println("Applying persistent parameters to nodes...");
    applyParametersToNodes();
    Serial.println("✅ Parameters applied successfully");
    
    // ====================================================================
    // ACTIVATION DE L'INTERFACE
    // ====================================================================
    
    BorneUniverselle::enableInterface(true);
    Serial.println("✅ Interface enabled for client");
    
    // ====================================================================
    // MARQUAGE COMME INITIALISÉ
    // ====================================================================
    
    initialStateLoaded = true;
    
    uint32_t duration = millis() - start;
    Serial.println("========================================");
    Serial.printf("RessortRoyal2::initialStateLoadedHandler - Terminé en %lu ms\n", duration);
    Serial.println("========================================");
}

// ========================================
// ON FILE SAVED
// ========================================

void RessortRoyal2::onFileSaved(const char* path) {
    // Validation des paramètres
    if (!path) {
        Serial.println("onFileSaved: Chemin invalide");
        return;
    }

    // Filtrer les modifications internes
    if (!shouldProcessFileCallback(path)) {
        Serial.printf("Fichier %s modifié en interne, ignoré\n", path);
        return;
    }

    Serial.printf("========================================\n");
    Serial.printf("RessortRoyal2::onFileSaved: %s\n", path);
    Serial.printf("========================================\n");

    // Fichier de configuration RessortRoyal2.json
    if (strcmp(path, CONFIG_FILE_NAME) == 0) {
        Serial.println("Fichier RessortRoyal2.json modifié → handleRessortRoyal2ConfigFileChanged()");
        handleRessortRoyal2ConfigFileChanged();
        return;
    }
}

// ========================================
// VALIDATE CONFIG FILE
// ========================================

bool RessortRoyal2::validateConfigFile(const char* path, const JsonDocument& doc, String& errorMsg) {
    // Validation basique pour RessortRoyal2
    // Pour l'instant, on accepte tout
    return true;
}

// ========================================
// CAN DELETE FILE
// ========================================

bool RessortRoyal2::canDeleteFile(const char* path) {
    // Protéger le fichier de configuration principal
    if (strcmp(path, CONFIG_FILE_NAME) == 0) {
        Serial.printf("❌ Cannot delete protected file: %s\n", path);
        return false;
    }
    
    return true;
}

// ========================================
// HOOKS DE TRANSITION - IMPLÉMENTATIONS
// ========================================

void RessortRoyal2::onStateEnter(int newState, int oldState) {
    State ressortNewState = static_cast<State>(newState);
    State ressortOldState = static_cast<State>(oldState);
    
    switch (ressortNewState) {
        case State::UNDEFINED:
            Serial.println("⚠️  État UNDEFINED - Initialisation en cours");
            break;
            
        case State::INITIALIZING:
            Serial.println("🔧 Initialisation de la machine RessortRoyal2");
            // Reset des flags et variables
            inCycle = false;
            cycleCounter = 0;
            goingPhase = true;
            emergencyPhase = 0;
            PLC_Tools::logDiagnostic("Initialisation RessortRoyal2");
            break;
            
        case State::EMERGENCY:
            Serial.printf("🚨 Entrée en état EMERGENCY depuis %s\n", 
                         getStateNameFromTable(ressortOldState));
            
            // Déterminer l'état de retour
            emergencyTargetState = getEmergencyReturnState();
            emergencyPhase = 0;
            
            Serial.printf("🎯 Emergency target state: %s\n", 
                         getStateNameFromTable(emergencyTargetState));
            
            // Arrêter tous les mouvements
            if (sureServo) {
                sureServo->stopMovement();
            }
            
            // Désactiver les modes
            if (jog) jog->setValue(false);
            if (freeRun) freeRun->setValue(false);
            if (goAndBack) goAndBack->setValue(false);
            
            inCycle = false;
            
            PLC_Tools::logDiagnostic("Entrée en mode EMERGENCY");
            break;
            
        case State::STOP:
            Serial.println("🛑 État STOP - Machine arrêtée");
            
            // S'assurer que tous les mouvements sont arrêtés
            if (sureServo) {
                sureServo->stopMovement();
            }
            break;
            
        case State::IDLE:
            Serial.println("✅ État IDLE - Machine prête");
            BorneUniverselle::prepareMessage(SUCCESS, "Machine prête");
            break;
            
        case State::HOMING:
            Serial.println("🏠 Début du homing");
            BorneUniverselle::prepareMessage(INFO, "Recherche de l'origine en cours...");
            break;
            
        case State::JOGGING:
            Serial.println("🎮 Mode JOG activé");
            BorneUniverselle::prepareMessage(INFO, "Mode JOG - Utilisez FWD/RWD");
            break;
            
        case State::FREE_RUNNING:
            Serial.println("🔄 Mode Free Run activé");
            BorneUniverselle::prepareMessage(INFO, "Mode Free Run - Rotation continue");
            break;
            
        case State::CYCLING:
            Serial.println("🔁 Mode Cycle activé");
            BorneUniverselle::prepareMessage(INFO, "Mode Cycle - Aller-retour automatique");
            break;
            
        case State::GOING:
            Serial.println("➡️  Phase aller");
            goingMovementStarted = false;  // Reset pour nouvelle phase
            break;
            
        case State::RETURNING:
            Serial.println("⬅️  Phase retour");
            returningMovementStarted = false;  // Reset pour nouvelle phase
            break;
            
        default:
            break;
    }
}

void RessortRoyal2::onStateExit(int oldState, int newState) {
    State ressortOldState = static_cast<State>(oldState);
    State ressortNewState = static_cast<State>(newState);
    
    switch (ressortOldState) {
        case State::EMERGENCY:
            if (ressortNewState == State::IDLE || ressortNewState == State::STOP) {
                Serial.println("✅ Sortie du mode EMERGENCY");
                BorneUniverselle::prepareMessage(SUCCESS, "Sortie du mode urgence");
            }
            break;
            
        case State::JOGGING:
            // Arrêter le JOG proprement
            if (sureServo) {
                sureServo->stopJog();
            }
            break;
            
        case State::FREE_RUNNING:
            // Arrêter le free run
            if (triggerPR) {
                triggerPR->setValue(false);
            }
            break;
            
        case State::CYCLING:
            // Sauvegarder le compteur de cycles
            if (parameters.numberOfCyclesMade != cycleCounter) {
                parameters.numberOfCyclesMade = cycleCounter;
            }
            break;
            
        default:
            break;
    }
}

void RessortRoyal2::onTransitionComplete(int newState, int oldState) {
    // Log détaillé des transitions importantes
    State ressortNewState = static_cast<State>(newState);
    State ressortOldState = static_cast<State>(oldState);
    
    if (ressortNewState == State::EMERGENCY || ressortOldState == State::EMERGENCY) {
        Serial.printf("%lu:: Transition critique: %s -> %s\r\n", 
                      (unsigned long)millis(), 
                      stateToString(oldState), 
                      stateToString(newState));
    }
}

// ========================================
// GET EMERGENCY RETURN STATE
// ========================================

RessortRoyal2::State RessortRoyal2::getEmergencyReturnState() const {
    // Déterminer l'état de retour en fonction de l'état précédent
    State prevState = static_cast<State>(getPreviousState());
    
    // Si on était en JOGGING ou HOMING, retourner à IDLE si home fait, sinon STOP
    if (prevState == State::JOGGING || prevState == State::HOMING) {
        if (homeDone && homeDone->getValue()) {
            return State::IDLE;
        } else {
            return State::STOP;
        }
    }
    
    // Pour tous les autres états opérationnels, retourner à IDLE si home fait
    if (prevState == State::FREE_RUNNING || 
        prevState == State::CYCLING ||
        prevState == State::GOING ||
        prevState == State::RETURNING) {
        return State::IDLE;
    }
    
    // Par défaut, retourner à STOP
    return State::STOP;
}

// ========================================
// TRANSITION AVEC CONTEXTE
// ========================================

void RessortRoyal2::transitionToState(State newState, ContextCode contextCode) {
    // Convertir l'état et le contexte en int pour BusinessLogic
    int newStateInt = static_cast<int>(newState);
    uint32_t context = static_cast<uint32_t>(contextCode);
    
    // Appeler la méthode de BusinessLogic
    transitionWithContext(newStateInt, context);
}

// ========================================
// START STATE MACHINE
// ========================================

bool RessortRoyal2::startStateMachine() {
    Serial.println("RessortRoyal2::startStateMachine()");
    uint32_t startupTime = millis();

    Serial.println("Initialisation des paramètres");
    Serial.println("------------------------------");
    
    // Transition vers l'état INITIALIZING
    transitionToState(State::INITIALIZING);
    
    Serial.printf("RessortRoyal2::startStateMachine() - Durée démarrage: %lu ms\n", 
                  (unsigned long)(millis() - startupTime));
    return true;
}

// ========================================
// DO BUSINESS LOGIC - BOUCLE PRINCIPALE
// ========================================

bool RessortRoyal2::doBusinessLogic() {
    uint32_t startTotal = millis();
    uint32_t now = startTotal;
    
    // =====================================
    // 1. TRAITEMENT SURESERVO
    // =====================================
    if (sureServo) {
        sureServo->update();
    }
    
    // =====================================
    // 2. VÉRIFICATION PLC BROKEN
    // =====================================
    if (BorneUniverselle::getInstance()->isPlcBroken()) {
        Serial.printf("%lu:: PLC broken, exiting\r\n", (unsigned long)now);
        return false;
    }
    
    // =====================================
    // 3. HANDLE INTERRUPTS
    // =====================================
    handleInterrupts();
    
    // =====================================
    // 4. UPDATE OUTPUTS
    // =====================================
    updateOutputs();
    
    // =====================================
    // 5. MACHINE À ÉTATS
    // =====================================
    State state = getCurrentState();
    bool handlerResult = false;
    
    switch(state) {
        case State::UNDEFINED:
            handlerResult = handleUndefinedState(now);
            break;
            
        case State::INITIALIZING:
            handlerResult = handleInitializingState(now);
            break;
            
        case State::STOP:
            handlerResult = handleStopState(now);
            break;
            
        case State::IDLE:
            handlerResult = handleIdleState(now);
            break;
            
        case State::EMERGENCY:
            handlerResult = handleEmergencyState(now);
            break;
            
        case State::HOMING:
            handlerResult = handleHomingState(now);
            break;
            
        case State::JOGGING:
            handlerResult = handleJoggingState(now);
            break;
            
        case State::FREE_RUNNING:
            handlerResult = handleFreeRunningState(now);
            break;
            
        case State::CYCLING:
            handlerResult = handleCyclingState(now);
            break;
            
        case State::GOING:
            handlerResult = handleGoingState(now);
            break;
            
        case State::RETURNING:
            handlerResult = handleReturningState(now);
            break;
            
        default:
            Serial.printf("ERREUR: État inconnu: %d\n", static_cast<int>(state));
            transitionToState(State::EMERGENCY);
            break;
    }
    
    if (!handlerResult) {
        return false;
    }
    
    return true;
}

// ========================================
// APPLY PARAMETERS TO NODES
// ========================================

void RessortRoyal2::applyParametersToNodes() {
    Serial.println("RessortRoyal2::applyParametersToNodes - Début");
    
    // Appliquer les paramètres de mouvement
    if (userTarget) {
        userTarget->setValue(parameters.userTarget);
        Serial.printf("  User target: %u\n", parameters.userTarget);
    }
    
    if (returnPos) {
        returnPos->setValue(parameters.returnPos);
        Serial.printf("  Return position: %u\n", parameters.returnPos);
    }
    
    if (vJogSpeed) {
        vJogSpeed->setValue(parameters.jogSpeed);
        Serial.printf("  Jog speed: %u\n", parameters.jogSpeed);
    }
    
    if (vCycleSpeed) {
        vCycleSpeed->setValue(parameters.cycleSpeed);
        Serial.printf("  Cycle speed: %u\n", parameters.cycleSpeed);
    }
    
    // Appliquer les paramètres de cycle
    if (numberOfCyclesToDo) {
        numberOfCyclesToDo->setValue(parameters.numberOfCyclesToDo);
        Serial.printf("  Cycles to do: %u\n", parameters.numberOfCyclesToDo);
    }
    
    if (numberOfCyclesMade) {
        numberOfCyclesMade->setValue(parameters.numberOfCyclesMade);
        Serial.printf("  Cycles made: %u\n", parameters.numberOfCyclesMade);
    }
    
    // Appliquer les paramètres de contrôle
    if (fullTorque) {
        fullTorque->setValue(parameters.fullTorque);
        Serial.printf("  Full torque: %s\n", parameters.fullTorque ? "true" : "false");
    }
    
    if (maxTorque) {
        uint16_t torqueValue = parameters.fullTorque ? 100 : parameters.initialTorque;
        maxTorque->setValue(torqueValue);
        Serial.printf("  Max torque: %u%%\n", torqueValue);
    }
    
    Serial.println("RessortRoyal2::applyParametersToNodes - Terminé");
}

// ========================================
// HANDLE CONFIG FILE CHANGED
// ========================================

void RessortRoyal2::handleRessortRoyal2ConfigFileChanged() {
    Serial.println("========================================");
    Serial.println("RessortRoyal2::handleRessortRoyal2ConfigFileChanged");
    Serial.println("========================================");
    
    // Relire le fichier de configuration
    if (readDedicacedConfigFile()) {
        Serial.println("✅ Configuration rechargée avec succès");
        
        // Réappliquer les paramètres aux nœuds
        applyParametersToNodes();
        
        BorneUniverselle::prepareMessage(SUCCESS, 
            "Configuration RessortRoyal2 rechargée avec succès");
    } else {
        Serial.println("❌ Erreur lors du rechargement de la configuration");
        BorneUniverselle::prepareMessage(ERROR, 
            "Erreur lors du rechargement de la configuration");
    }
}

// ========================================
// HANDLERS D'ÉTATS - IMPLÉMENTATIONS
// ========================================

bool RessortRoyal2::handleUndefinedState(uint32_t now) {
    // Transition automatique vers INITIALIZING
    transitionToState(State::INITIALIZING);
    return true;
}

bool RessortRoyal2::handleInitializingState(uint32_t now) {
    printCurrentState();
    
    ServoDrive::OperationStatus status;
    
    if (!sureServo->handleInitializing(status)) {
        BorneUniverselle::getInstance()->setPlcBroken("Drive init failed");
        return false;
    }
    
    switch (status) {
        case ServoDrive::OperationStatus::COMPLETED:
            if (driveInitialised) driveInitialised->setValue(true);
            BorneUniverselle::prepareMessage(SUCCESS, "Servo drive initialisé avec succès");
            transitionToState(State::STOP);
            break;
            
        case ServoDrive::OperationStatus::SERVO_DRIVE_FATAL_ERROR:
            transitionToState(State::EMERGENCY, ContextCode::SERVO_ALARM);
            if (driveInitialised) driveInitialised->setValue(false);
            BorneUniverselle::prepareMessage(ERROR, "Erreur fatale servo drive");
            break;
            
        case ServoDrive::OperationStatus::SERVO_DRIVE_ERROR:
            transitionToState(State::EMERGENCY, ContextCode::INIT_FAILED);
            if (driveInitialised) driveInitialised->setValue(false);
            BorneUniverselle::prepareMessage(ERROR, "Erreur initialisation servo drive");
            break;
            
        case ServoDrive::OperationStatus::IN_PROGRESS:
        default:
            // Initialisation en cours
            break;
    }
    
    return true;
}

bool RessortRoyal2::handleStopState(uint32_t now) {
    printCurrentState();
    interfaceTreatment();
    checkEmergencyConditions(now);
    
    // PRIORITÉ 1: Mode JOG
    if (jog && jog->getIsChanged() && jog->getValue()) {
        transitionToState(State::JOGGING, ContextCode::USER_REQUEST);
        return true;
    }
    
    // PRIORITÉ 2: Homing si nécessaire
    if (startCycle && startCycle->getIsChanged() && startCycle->getValue()) {
        if (!homeDone || !homeDone->getValue()) {
            BorneUniverselle::prepareMessage(INFO, "Homing requis avant de démarrer");
            transitionToState(State::HOMING, ContextCode::USER_REQUEST);
            return true;
        }
    }
    
    // PRIORITÉ 3: Mode Free Run
    if (freeRun && freeRun->getIsChanged() && freeRun->getValue()) {
        transitionToState(State::FREE_RUNNING, ContextCode::USER_REQUEST);
        return true;
    }
    
    // PRIORITÉ 4: Mode Cycle (go and back)
    if (goAndBack && goAndBack->getIsChanged() && goAndBack->getValue()) {
        if (!homeDone || !homeDone->getValue()) {
            BorneUniverselle::prepareMessage(WARNING, "Homing requis pour mode cycle");
            return true;
        }
        transitionToState(State::CYCLING, ContextCode::USER_REQUEST);
        return true;
    }
    
    return true;
}

bool RessortRoyal2::handleIdleState(uint32_t now) {
    printCurrentState();
    interfaceTreatment();
    checkEmergencyConditions(now);
    
    // IDLE est similaire à STOP mais indique que le système est prêt
    
    // Mode JOG
    if (jog && jog->getIsChanged() && jog->getValue()) {
        transitionToState(State::JOGGING, ContextCode::USER_REQUEST);
        return true;
    }
    
    // Mode Free Run
    if (freeRun && freeRun->getIsChanged() && freeRun->getValue()) {
        transitionToState(State::FREE_RUNNING, ContextCode::USER_REQUEST);
        return true;
    }
    
    // Mode Cycle
    if (goAndBack && goAndBack->getIsChanged() && goAndBack->getValue()) {
        transitionToState(State::CYCLING, ContextCode::USER_REQUEST);
        return true;
    }
    
    return true;
}

bool RessortRoyal2::handleEmergencyState(uint32_t now) {
    printCurrentState();
    
    // Phase 0: Vérifier si on peut sortir de l'urgence
    if (emergencyPhase == 0) {
        // Vérifier que les E-stops sont relâchés
        bool eStopActive = false;
        if (eStopA && !eStopA->getValue()) eStopActive = true;
        if (eStopB && !eStopB->getValue()) eStopActive = true;
        
        if (eStopActive) {
            PLC_Tools::sendPeriodicMessage(true, ERROR, 
                "Arrêt d'urgence actif - Relâcher le bouton E-STOP");
            return true;
        }
        
        // Vérifier alarme servo
        if (servoAlarm && servoAlarm->getValue()) {
            PLC_Tools::sendPeriodicMessage(true, ERROR, 
                "Alarme servo active - Appuyer sur Reset Alarms");
            return true;
        }
        
        // Conditions OK, passer en phase 1
        emergencyPhase = 1;
        BorneUniverselle::prepareMessage(INFO, 
            "Conditions OK - Appuyez sur Reset Alarms pour continuer");
        return true;
    }
    
    // Phase 1: Attendre reset utilisateur
    if (emergencyPhase == 1) {
        if (!alarmsReset || !alarmsReset->getValue()) {
            return true; // Attendre
        }
        
        // Reset demandé, passer en phase 2
        emergencyPhase = 2;
        BorneUniverselle::prepareMessage(INFO, "Reset en cours...");
        return true;
    }
    
    // Phase 2: Effectuer le reset
    if (emergencyPhase == 2) {
        // Réinitialiser les sorties
        if (immediateStop) immediateStop->setValue(false);
        
        // Reset du servo drive si nécessaire
        if (servoAlarm && servoAlarm->getValue()) {
            if (!resetDrive("Emergency reset")) {
                BorneUniverselle::prepareMessage(ERROR, "Échec reset servo drive");
                emergencyPhase = 1;
                return true;
            }
        }
        
        // Reset OK, sortir de l'urgence
        emergencyPhase = 0;
        BorneUniverselle::prepareMessage(SUCCESS, "Reset effectué avec succès");
        
        // Retourner à l'état cible (déterminé dans onStateEnter)
        transitionToState(emergencyTargetState, ContextCode::NORMAL);
        return true;
    }
    
    return true;
}

bool RessortRoyal2::handleHomingState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    ServoDrive::OperationStatus status;
    
    if (!sureServo->handleHoming(status)) {
        BorneUniverselle::getInstance()->setPlcBroken("Homing failed");
        return false;
    }
    
    switch (status) {
        case ServoDrive::OperationStatus::COMPLETED:
            BorneUniverselle::prepareMessage(SUCCESS, "Homing terminé avec succès");
            if (homeDone) homeDone->setValue(true);
            transitionToState(State::IDLE, ContextCode::MOVEMENT_SUCCESS);
            break;
            
        case ServoDrive::OperationStatus::SERVO_DRIVE_FATAL_ERROR:
            BorneUniverselle::prepareMessage(ERROR, "Erreur fatale pendant homing");
            transitionToState(State::EMERGENCY, ContextCode::SERVO_ALARM);
            break;
            
        case ServoDrive::OperationStatus::SERVO_DRIVE_ERROR:
            BorneUniverselle::prepareMessage(ERROR, "Erreur pendant homing");
            transitionToState(State::EMERGENCY, ContextCode::SERVO_ALARM);
            break;
            
        case ServoDrive::OperationStatus::IN_PROGRESS:
        default:
            // Homing en cours
            break;
    }
    
    return true;
}

bool RessortRoyal2::handleJoggingState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    // Sortie du mode JOG
    if (jog && jog->getIsChanged() && !jog->getValue()) {
        BorneUniverselle::prepareMessage(INFO, "Sortie du mode JOG");
        
        // Retourner à IDLE si home fait, sinon STOP
        if (homeDone && homeDone->getValue()) {
            transitionToState(State::IDLE, ContextCode::NORMAL);
        } else {
            transitionToState(State::STOP, ContextCode::NORMAL);
        }
        return true;
    }
    
    // Gestion des commandes JOG
    bool fwdActive = fwd && fwd->getValue();
    bool rwdActive = rwd && rwd->getValue();
    
    // Les deux boutons ne peuvent pas être actifs en même temps
    if (fwdActive && rwdActive) {
        BorneUniverselle::prepareMessage(WARNING, "Conflit FWD/RWD - Relâcher un bouton");
        return true;
    }
    
    // Gérer la vitesse JOG
    if (vJogSpeed && vJogSpeed->getIsChanged()) {
        uint32_t speed = vJogSpeed->getValue();
        setJogSpeed(speed);
    }
    
    // Gérer le couple
    if (fullTorque && fullTorque->getIsChanged()) {
        if (maxTorque) {
            uint16_t torque = fullTorque->getValue() ? 100 : parameters.initialTorque;
            maxTorque->setValue(torque);
        }
    }
    
    // Exécuter le mouvement JOG via SureServo
    if (sureServo) {
        if (fwdActive) {
            // JOG en avant
            sureServo->jogForward();
        } else if (rwdActive) {
            // JOG en arrière
            sureServo->jogReverse();
        } else {
            // Arrêter le mouvement
            sureServo->stopJog();
        }
    }
    
    return true;
}

bool RessortRoyal2::handleFreeRunningState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    // Sortie du mode free run
    if (freeRun && freeRun->getIsChanged() && !freeRun->getValue()) {
        BorneUniverselle::prepareMessage(INFO, "Sortie du mode Free Run");
        
        // Arrêter le mouvement
        if (sureServo) {
            sureServo->stopMovement();
        }
        
        transitionToState(State::IDLE, ContextCode::NORMAL);
        return true;
    }
    
    // En mode free run, le servo tourne en continu à la vitesse de cycle
    // Utiliser PR1 pour mouvement continu
    if (vCycleSpeed && vCycleSpeed->getIsChanged()) {
        uint32_t speed = vCycleSpeed->getValue();
        if (pr1Speed) {
            pr1Speed->setValue(speed);
        }
    }
    
    // Trigger PR1 pour démarrer le mouvement continu
    static bool freeRunStarted = false;
    if (!freeRunStarted && triggerPR) {
        triggerPR->setValue(true);
        freeRunStarted = true;
    }
    
    // Reset du flag à la sortie
    if (!freeRun || !freeRun->getValue()) {
        freeRunStarted = false;
    }
    
    return true;
}

bool RessortRoyal2::handleCyclingState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    // Sortie du mode cycle
    if (goAndBack && goAndBack->getIsChanged() && !goAndBack->getValue()) {
        BorneUniverselle::prepareMessage(INFO, "Arrêt du mode cycle");
        
        // Arrêter le mouvement
        if (sureServo) {
            sureServo->stopMovement();
        }
        
        inCycle = false;
        cycleCounter = 0;
        transitionToState(State::IDLE, ContextCode::NORMAL);
        return true;
    }
    
    // Réinitialiser le compteur si demandé
    if (nbCyclesClear && nbCyclesClear->getIsChanged() && nbCyclesClear->getValue()) {
        parameters.numberOfCyclesMade = 0;
        cycleCounter = 0;
        if (numberOfCyclesMade) {
            numberOfCyclesMade->setValue(0);
        }
        BorneUniverselle::prepareMessage(INFO, "Compteur de cycles réinitialisé");
    }
    
    // Vérifier si on a atteint le nombre de cycles voulus
    if (numberOfCyclesToDo && numberOfCyclesToDo->getValue() > 0) {
        if (cycleCounter >= numberOfCyclesToDo->getValue()) {
            BorneUniverselle::prepareMessage(SUCCESS, "Cycles terminés");
            inCycle = false;
            transitionToState(State::IDLE, ContextCode::CYCLE_COMPLETE);
            return true;
        }
    }
    
    // Démarrer le premier cycle ou continuer
    if (!inCycle) {
        inCycle = true;
        goingPhase = true;
        transitionToState(State::GOING, ContextCode::NORMAL);
    }
    
    return true;
}

bool RessortRoyal2::handleGoingState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    // Démarrer le mouvement aller
    if (!goingMovementStarted) {
        uint32_t target = userTarget ? userTarget->getValue() : 0;
        uint32_t speed = vCycleSpeed ? vCycleSpeed->getValue() : 1000;
        
        if (targetGo) targetGo->setValue(target);
        if (pr1Speed) pr1Speed->setValue(speed);
        if (triggerPR) triggerPR->setValue(true);
        
        goingMovementStarted = true;
        BorneUniverselle::prepareMessage(INFO, "Phase aller démarrée");
    }
    
    // Vérifier si la position est atteinte
    if (atTarget && atTarget->getValue()) {
        goingMovementStarted = false;
        goingPhase = false;
        
        BorneUniverselle::prepareMessage(INFO, "Position cible atteinte");
        transitionToState(State::RETURNING, ContextCode::POSITION_REACHED);
    }
    
    return true;
}

bool RessortRoyal2::handleReturningState(uint32_t now) {
    printCurrentState();
    checkEmergencyConditions(now);
    
    // Démarrer le mouvement retour
    if (!returningMovementStarted) {
        uint32_t target = returnPos ? returnPos->getValue() : 0;
        uint32_t speed = vCycleSpeed ? vCycleSpeed->getValue() : 1000;
        
        if (targetBack) targetBack->setValue(target);
        if (pr2Speed) pr2Speed->setValue(speed);
        if (triggerPR) triggerPR->setValue(true);
        
        returningMovementStarted = true;
        BorneUniverselle::prepareMessage(INFO, "Phase retour démarrée");
    }
    
    // Vérifier si la position est atteinte
    if (atTarget && atTarget->getValue()) {
        returningMovementStarted = false;
        goingPhase = true;
        
        // Incrémenter le compteur de cycles
        cycleCounter++;
        parameters.numberOfCyclesMade = cycleCounter;
        if (numberOfCyclesMade) {
            numberOfCyclesMade->setValue(cycleCounter);
        }
        
        BorneUniverselle::prepareMessage(INFO, "Cycle terminé");
        
        // Retourner à CYCLING pour le prochain cycle
        transitionToState(State::CYCLING, ContextCode::CYCLE_COMPLETE);
    }
    
    return true;
}

// ========================================
// MÉTHODES UTILITAIRES - IMPLÉMENTATIONS
// ========================================

void RessortRoyal2::checkEmergencyConditions(uint32_t now) {
    State currentState = getCurrentState();
    
    // Si déjà en EMERGENCY, ne pas re-déclencher
    if (currentState == State::EMERGENCY) {
        return;
    }
    
    // Vérifier E-Stop A
    if (eStopA && eStopA->getIsChanged() && !eStopA->getValue()) {
        BorneUniverselle::prepareMessage(ERROR, "Arrêt d'urgence A activé !");
        transitionToState(State::EMERGENCY, ContextCode::EMERGENCY_STOP);
        return;
    }
    
    // Vérifier E-Stop B
    if (eStopB && eStopB->getIsChanged() && !eStopB->getValue()) {
        BorneUniverselle::prepareMessage(ERROR, "Arrêt d'urgence B activé !");
        transitionToState(State::EMERGENCY, ContextCode::EMERGENCY_STOP);
        return;
    }
    
    // Vérifier alarme servo
    if (servoAlarm && servoAlarm->getIsChanged() && servoAlarm->getValue()) {
        BorneUniverselle::prepareMessage(ERROR, "Alarme servo drive !");
        transitionToState(State::EMERGENCY, ContextCode::SERVO_ALARM);
        return;
    }
    
    // Vérifier immediate stop
    if (immediateStop && immediateStop->getIsChanged() && immediateStop->getValue()) {
        BorneUniverselle::prepareMessage(ERROR, "Arrêt immédiat activé !");
        transitionToState(State::EMERGENCY, ContextCode::EMERGENCY_STOP);
        return;
    }
}

void RessortRoyal2::handleInterrupts() {
    // Gérer les demandes d'arrêt immédiat
    if (immediateStop && immediateStop->getIsChanged() && immediateStop->getValue()) {
        if (sureServo) {
            sureServo->stopMovement();
        }
    }
    
    // Gérer le reset des alarmes
    if (alarmsReset && alarmsReset->getIsChanged() && alarmsReset->getValue()) {
        resetDrive("User reset request");
    }
}

void RessortRoyal2::updateOutputs() {
    // Mettre à jour le buzzer si nécessaire
    State currentState = getCurrentState();
    if (buzzer) {
        bool shouldBuzz = (currentState == State::EMERGENCY);
        if (buzzer->getValue() != shouldBuzz) {
            buzzer->setValue(shouldBuzz);
        }
    }
    
    // Mettre à jour servoOn
    if (servoOn) {
        bool shouldBeOn = (currentState != State::UNDEFINED && 
                          currentState != State::EMERGENCY);
        if (servoOn->getValue() != shouldBeOn) {
            servoOn->setValue(shouldBeOn);
        }
    }
    
    // Synchroniser le torque
    if (fullTorque && maxTorque) {
        uint16_t targetTorque = fullTorque->getValue() ? 100 : parameters.initialTorque;
        if (maxTorque->getValue() != targetTorque) {
            maxTorque->setValue(targetTorque);
        }
    }
}

void RessortRoyal2::interfaceTreatment() {
    // Gérer les changements de vitesse JOG
    if (vJogSpeed && vJogSpeed->getIsChanged()) {
        uint32_t speed = vJogSpeed->getValue();
        setJogSpeed(speed);
        parameters.jogSpeed = speed;
    }
    
    // Gérer les changements de vitesse cycle
    if (vCycleSpeed && vCycleSpeed->getIsChanged()) {
        cycleSpeedChange();
    }
    
    // Gérer le changement de target
    if (userTarget && userTarget->getIsChanged()) {
        parameters.userTarget = userTarget->getValue();
    }
    
    // Gérer le changement de position de retour
    if (returnPos && returnPos->getIsChanged()) {
        parameters.returnPos = returnPos->getValue();
    }
    
    // Gérer le changement du nombre de cycles
    if (numberOfCyclesToDo && numberOfCyclesToDo->getIsChanged()) {
        parameters.numberOfCyclesToDo = numberOfCyclesToDo->getValue();
    }
    
    // Afficher les alarmes et status périodiquement
    static uint32_t lastDisplay = 0;
    if (millis() - lastDisplay > 5000) {
        displayAlarmsAndStatus();
        lastDisplay = millis();
    }
}

void RessortRoyal2::displayAlarmsAndStatus() {
    // Afficher les alarmes si présentes
    if (servoAlarm && servoAlarm->getValue()) {
        if (alarms) {
            uint16_t alarmCode = alarms->getValue();
            Serial.printf("⚠️ Alarme servo: 0x%04X\n", alarmCode);
        }
    }
    
    // Afficher la position courante
    if (position) {
        uint32_t pos = position->getValue();
        Serial.printf("Position: %u pulses\n", pos);
    }
    
    // Afficher le status du drive
    if (statusDrive) {
        uint16_t status = statusDrive->getValue();
        Serial.printf("Status drive: 0x%04X\n", status);
    }
}

bool RessortRoyal2::setJogSpeed(uint32_t speed) {
    if (!jogSpeed) {
        return false;
    }
    
    // Limiter la vitesse JOG à une valeur raisonnable
    if (speed > 5000) {
        speed = 5000;
        BorneUniverselle::prepareMessage(WARNING, "Vitesse JOG limitée à 5000");
    }
    
    jogSpeed->setValue(static_cast<uint16_t>(speed));
    currentJogSpeed = speed;
    
    Serial.printf("Vitesse JOG configurée: %u\n", speed);
    return true;
}

void RessortRoyal2::cycleSpeedChange() {
    if (!vCycleSpeed) {
        return;
    }
    
    uint32_t speed = vCycleSpeed->getValue();
    parameters.cycleSpeed = speed;
    
    // Mettre à jour PR1 et PR2 speed
    if (pr1Speed) {
        pr1Speed->setValue(speed);
    }
    if (pr2Speed) {
        pr2Speed->setValue(speed);
    }
    
    Serial.printf("Vitesse cycle configurée: %u\n", speed);
}

bool RessortRoyal2::resetDrive(const char* context) {
    Serial.printf("RessortRoyal2::resetDrive - Contexte: %s\n", context ? context : "unknown");
    
    if (!sureServo) {
        Serial.println("❌ SureServo non initialisé");
        return false;
    }
    
    // Utiliser la méthode resetAlarms du SureServo
    if (!sureServo->resetAlarms()) {
        Serial.println("❌ Échec reset alarmes servo");
        return false;
    }
    
    Serial.println("✅ Reset servo effectué avec succès");
    return true;
}
